var classhttpsserver_1_1WebsocketHandler =
[
    [ "WebsocketHandler", "classhttpsserver_1_1WebsocketHandler.html#aaac69a72a758d24a6a399233a2391be8", null ],
    [ "~WebsocketHandler", "classhttpsserver_1_1WebsocketHandler.html#a16ae39a49db124c41592e8e5dfcf614d", null ],
    [ "close", "classhttpsserver_1_1WebsocketHandler.html#a7a0f8c9cc74e5c30d9b7f19573297ef0", null ],
    [ "closed", "classhttpsserver_1_1WebsocketHandler.html#aa5a69ec59ae16c3a59ef96a4509b7213", null ],
    [ "initialize", "classhttpsserver_1_1WebsocketHandler.html#a64383ed5635d7a60a273d2e0f741df32", null ],
    [ "loop", "classhttpsserver_1_1WebsocketHandler.html#a87e2bb2bb7e68d7ecfa37e60d532cc97", null ],
    [ "onClose", "classhttpsserver_1_1WebsocketHandler.html#a9a60cb5f4db6d0267b6114f06aa45116", null ],
    [ "onError", "classhttpsserver_1_1WebsocketHandler.html#a18f912105b6c238dadd1f2d771cff1bc", null ],
    [ "onMessage", "classhttpsserver_1_1WebsocketHandler.html#a8c0c9881bd80ec13215a64723d37f28d", null ],
    [ "send", "classhttpsserver_1_1WebsocketHandler.html#acd6abd98390115112c1d3790c839bd5a", null ],
    [ "send", "classhttpsserver_1_1WebsocketHandler.html#a2711aa6a22c4218596f30681a993b297", null ]
];