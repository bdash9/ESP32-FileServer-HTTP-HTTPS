var classhttpsserver_1_1ConnectionContext =
[
    [ "ConnectionContext", "classhttpsserver_1_1ConnectionContext.html#a2031b79e8f1b68b65028eeeb6bf134a8", null ],
    [ "~ConnectionContext", "classhttpsserver_1_1ConnectionContext.html#a1001981e4a00ead11dc7c005d7172ae0", null ],
    [ "getCacheSize", "classhttpsserver_1_1ConnectionContext.html#a24c1cbfc88448164c3578de1d92aed62", null ],
    [ "getClientIP", "classhttpsserver_1_1ConnectionContext.html#a05cfff91da98519cf07355e53ee606d7", null ],
    [ "isSecure", "classhttpsserver_1_1ConnectionContext.html#ad81cdd3b01c72510e4f9907aca66ac99", null ],
    [ "pendingBufferSize", "classhttpsserver_1_1ConnectionContext.html#ac69f1128f50f56611e9381842d67b94f", null ],
    [ "readBuffer", "classhttpsserver_1_1ConnectionContext.html#ac5bf1981fe8ad3a271c1d7fde66e8e8d", null ],
    [ "setWebsocketHandler", "classhttpsserver_1_1ConnectionContext.html#a4b6ebe2d49634ef637e6bc283566f1c8", null ],
    [ "signalClientClose", "classhttpsserver_1_1ConnectionContext.html#a7c320593a3a29938a0a11d63fc3f5c37", null ],
    [ "signalRequestError", "classhttpsserver_1_1ConnectionContext.html#acf5be558fda61d4a2620028d6145ffef", null ],
    [ "writeBuffer", "classhttpsserver_1_1ConnectionContext.html#afbe180699d04d620411561b27bc85b4f", null ],
    [ "_wsHandler", "classhttpsserver_1_1ConnectionContext.html#a736506543291379027ecd4d5e2853418", null ]
];