# Documentation

This folder contains documentation of the internal structure of the library.

If not stated otherwise, diagrams have been created using [Umlet](https://www.umlet.com/).

## Class diagram

The following diagram shows the internal class structure of the library.

![Class diagram of esp32_https_server](https://github.com/fhessel/esp32_https_server/blob/master/extras/docs/esp32_https_server_classes.png?raw=true)